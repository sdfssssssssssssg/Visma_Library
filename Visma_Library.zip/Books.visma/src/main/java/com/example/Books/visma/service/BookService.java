package com.example.Books.visma.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.example.Books.visma.dao.BookDao;
import com.example.Books.visma.model.Book;

@Service
public class BookService {
	
	private final BookDao bookDao;
	
	@Autowired
	public BookService(@Qualifier("FakeDao") BookDao bookDao) {
		this.bookDao = bookDao;
	}

	public int addBook(Book book) {
		return bookDao.insertBook(book);
	}
	
	public List<Book> getAllBooks(){
		return bookDao.findAllBooks();
	}
	
	public Optional<Book> getBookById(UUID GUID){
		return bookDao.findBookById(GUID);
	}
	
	public int deleteBook(UUID GUID) {
		return bookDao.deleteBookbyId(GUID);
	}
	
	public int updatePerson(UUID GUID, Book newBook) {
		return bookDao.updateBookById(GUID, newBook);
	}
	
	public ArrayList<Book> getBooksByName(String name){
		return bookDao.findBooksByName(name);
	}
	
	public List<Book> getBooksByAuthor(String author){
		return bookDao.findBooksByAuthor(author);
	}
	
	public List<Book> getBooksByCategory(String category){
		return bookDao.findBooksByCategory(category);
	}
	
	public List<Book> getBooksByLanguage(String language){
		return bookDao.findBooksByLanguage(language);
	}
	
	public List<Book> getBooksByPublicationDate(long Publication_date){
		return bookDao.findBooksByPublicationDate(Publication_date);
	}
	
	public List<Book> getBooksByISBN(String ISBN){
		return bookDao.findBooksByISBN(ISBN);
	}
	
		
}
