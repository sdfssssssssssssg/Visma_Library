package com.example.Books.visma.api;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Books.visma.model.Book;
import com.example.Books.visma.service.BookService;

@RequestMapping("api/v1/book")
@RestController
public class BookController {

	private final BookService bookService;

	@Autowired
	public BookController(BookService bookService) {
		this.bookService = bookService;
	}

	@PostMapping
    public void addBook(@RequestBody Book book) {
    	bookService.addBook(book);
    }
	
	@GetMapping
	public List<Book> getAllBooks(){
		return bookService.getAllBooks();
	}
	
	@GetMapping(path = "/{GUID}")
	public Book getBookById(@PathVariable("GUID") UUID GUID) {
		return bookService.getBookById(GUID).orElse(null);
	}
	
	@DeleteMapping(path = "/{GUID}")
	public void deleteBookById(@PathVariable("GUID") UUID GUID) {
		bookService.deleteBook(GUID);
	}
	
	@PutMapping(path = "/{GUID}")
	public void updateBook(@PathVariable ("GUID") UUID GUID, @RequestBody Book bookToUpdate) {
		bookService.updatePerson(GUID, bookToUpdate);
	}
	
	@GetMapping(path = "byname/{name}")
	public ArrayList<Book> getBooksByName(@PathVariable("name") String name){
		return bookService.getBooksByName(name);
	}
	
	@GetMapping(path = "byauthor/{author}")
	public List<Book> getBooksByAuthor(@PathVariable("author") String author){
		return bookService.getBooksByAuthor(author);
	}
	
	@GetMapping(path = "bycategory/{category}")
	public List<Book> getBooksByCategory(@PathVariable("category") String category){
		return bookService.getBooksByCategory(category);
	}
	
	@GetMapping(path = "bylanguage/{language}")
	public List<Book> getBooksByLanguage(@PathVariable("language") String language){
		return bookService.getBooksByLanguage(language);
	}
	
	@GetMapping(path = "bypublicationdate/{publication_Date}")
	public List<Book> getBooksByPublicationDate(@PathVariable("publication_Date") long publication_Date){
		return bookService.getBooksByPublicationDate(publication_Date);
	}
	
	@GetMapping(path = "byISBN/{ISBN}")
	public List<Book> getBooksByISBN(@PathVariable("ISBN") String ISBN){
		return bookService.getBooksByISBN(ISBN);
	}
	
	
	
	
	
	

}
