package com.example.Books.visma.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class Library {
private List<Book> library = new ArrayList<Book>();
private List<Book> taken = new ArrayList<Book>();
private List<Book> NotTaken = new ArrayList<Book>();
private boolean takenOrNot;
private Client client = null;
private Date taken_date;

	
	public Library(boolean takenOrNot, Client client, Date taken_date) {
	this.takenOrNot = takenOrNot;
	this.client = client;
	this.taken_date = taken_date;
   }
	

	public List<Book> getAllBooks() {
		return library;
	}
	

	public void setAllBooks(List<Book> allBooks) {
		this.library = allBooks;
	}


	public boolean isTakenOrNot() {
		return takenOrNot;
	}




	public void setTakenOrNot(boolean takenOrNot) {
		this.takenOrNot = takenOrNot;
	}




	public Client getClient() {
		return client;
	}




	public void setClient(Client client) {
		this.client = client;
	}


	public Date getTaken_date() {
		return taken_date;
	}


	public void setTaken_date(Date taken_date) {
		this.taken_date = taken_date;
	}



	public void addToLibrary(Book book){
			library.add(book);
	}
	
	public void removeFromLibrary(Book book) {
		library.remove(book);
	}
	
	public void addToTaken(Book book){
		if(!taken.contains(book))
		taken.add(book);
		
}

}
