package com.example.Books.visma.dao;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.stereotype.Repository;
import com.example.Books.visma.model.Book;

@Repository("FakeDao")
public class FakeBookDataAccessService implements BookDao {

	public static List<Book> DB = new ArrayList<>(); 
	

	@Override
	public int insertBook(UUID GUID, Book book) {
		DB.add(new Book(GUID, 
				book.getName(),
				book.getAuthor(), 
				book.getCategory(), 
				book.getLanguage(), 
				book.getPublication_date(), 
				book.getISBN()));
		return 1;
	}

	@Override
	public List<Book> findAllBooks() {
		return DB;
	}

	@Override
	public Optional<Book> findBookById(UUID GUID) {
		return DB.stream().filter(book -> book.getGUID().equals(GUID)).findFirst();
	}
	
	@Override
	public ArrayList<Book> findBooksByName(String name) {
//		return library.stream().filter(book -> book.getName().equals(name)).collect(Collectors.toList());
		ArrayList<Book> booksByName = new ArrayList<Book>();
		for (Book b : DB) {
			if(b.getName().equals(name)) {
				booksByName.add(b);
			}
		}
		return booksByName;
	}
	
	@Override
	public List<Book> findBooksByAuthor(String author) {
		List<Book> booksByAuthor = new ArrayList<Book>();
		for (Book b : DB) {
			if(b.getAuthor().equals(author)) {
				booksByAuthor.add(b);
			}
		}
		return booksByAuthor;
	}
	
	
	@Override
	public List<Book> findBooksByCategory(String category) {
		return DB.stream().filter(book -> book.getCategory().equals(category)).collect(Collectors.toList());
	}
	
	@Override
	public List<Book> findBooksByLanguage(String language) {
		return DB.stream().filter(book -> book.getLanguage().equals(language)).collect(Collectors.toList());
	}
	
	@Override
	public List<Book> findBooksByISBN(String ISBN) {
		return DB.stream().filter(book -> book.getISBN().equals(ISBN)).collect(Collectors.toList());
	}
	
	@Override
	public List<Book> findBooksByPublicationDate(long Publication_date) {
		return DB.stream().filter(book -> book.getPublication_date() == Publication_date).collect(Collectors.toList());
	}
	
	@Override
	public int deleteBookbyId(UUID GUID) {
		Optional<Book> bookMaybe = findBookById(GUID);
		if (bookMaybe.isEmpty()) {
			return 0;
		}
		DB.remove(bookMaybe.get());
		return 1;
	}

	@Override
	public int updateBookById(UUID GUID, Book update) {
		return findBookById(GUID)
				.map(book -> {
					int indexOfBookToUpdate = DB.indexOf(book);
		            if (indexOfBookToUpdate >= 0) {
		            	DB.set(indexOfBookToUpdate, new Book(GUID,
		            			update.getName(),
		            			update.getAuthor(), 
		            			update.getCategory(), 
		            			update.getLanguage(), 
		            			update.getPublication_date(), 
		            			update.getISBN()));
		            	return 1;
		            }
		            return 0;
		}).orElse(0);
	}
	
	
}
