package com.example.Books.visma.model;

import java.util.ArrayList;
import java.util.List;

public class Client {
	String nameOfClient;
	List<Book> takenBooks = new ArrayList<Book>();
	
	public Client(String nameOfClient, List<Book> takenBooks) {
		super();
		this.nameOfClient = nameOfClient;
		this.takenBooks = takenBooks;
	}

	public String getNameOfClient() {
		return nameOfClient;
	}

	public void setNameOfClient(String nameOfClient) {
		this.nameOfClient = nameOfClient;
	}

	public List<Book> getTakenBooks() {
		return takenBooks;
	}

	public void setTakenBooks(List<Book> takenBooks) {
		this.takenBooks = takenBooks;
	}
	
	
	
	
	
	
	
	

	
	
	

}
