package com.example.Books.visma.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import com.example.Books.visma.model.Book;

public interface BookDao {

	 int insertBook (UUID GUID, Book book);
		default int insertBook(Book book) {
		 UUID GUID = UUID.randomUUID();
		 return insertBook(GUID, book);
	 }
		
		List<Book> findAllBooks();
		
		Optional<Book> findBookById(UUID GUID);
		
		ArrayList<Book> findBooksByName(String name);
		
		List<Book> findBooksByAuthor(String author);
		
		List<Book> findBooksByCategory(String category);
		
		List<Book> findBooksByLanguage(String language);
		
		List<Book> findBooksByPublicationDate(long Publication_date);
		
		int deleteBookbyId(UUID GUID);
		
		int updateBookById(UUID GUID, Book book);
}
