package com.example.Books.visma.model;

public class Client {
	String nameOfClient;
	
	public Client() {
		// TODO Auto-generated constructor stub
	}

}
