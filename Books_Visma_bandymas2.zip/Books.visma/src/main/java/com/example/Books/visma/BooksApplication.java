package com.example.Books.visma;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Repository;

import com.example.Books.visma.dao.BookDao;
import com.example.Books.visma.model.Book;

@SpringBootApplication
public class BooksApplication {
	

	public static void main(String[] args) {
		
		SpringApplication.run(BooksApplication.class, args);
	
		
//		List<Book> library2 = new ArrayList<Book>();
//		Book book = new Book();
//		book.setAuthor("Jack");
//		book.setName("Knyga");
//		book.setCategory("C");
//		book.setISBN("BN");
//		book.setPublication_date(2020);
//		library2.add(book);
//		
//		Book book2 = new Book();
//		book2.setAuthor("Klakkak");
//		book2.setName("Knyga");
//		book2.setCategory("C");
//		book2.setISBN("BN");
//		book2.setPublication_date(2020);
//		library2.add(book2);
//		
//		
//		JSONObject jsonObject = new JSONObject();
//		for (Book b : library2) {
//			//Inserting key-value pairs into the json object
//			  jsonObject.put("ID", b.getGUID());
//		      jsonObject.put("Name", b.getAuthor());
//		      jsonObject.put("Category", b.getCategory());
//		      jsonObject.put("ISBN", b.getISBN());
//		      jsonObject.put("PublicationDate", b.getPublication_date());
//		      jsonObject.put("Country", "India");
//		}
//	
//		try {
//	         FileWriter file = new FileWriter("/home/karolis/Desktop/Books.visma/output.json");
//	         file.write(jsonObject.toJSONString());
//	         file.close();
//	      } catch (IOException e) {
//	         // TODO Auto-generated catch block
//	         e.printStackTrace();
//	      }
//	      System.out.println("JSON file created: " + jsonObject);
		
		
//	try {
//		ObjectMapper mapper = new ObjectMapper();
//		InputStream inputStream = new FileInputStream (new File ("/home/karolis/demo/persons.json"));
//		FileWriter file = new FileWriter("/home/karolis/demo/output.json");
//		TypeReference<List<Book>> typeReference = new TypeReference<List<Book>>() {};
//		List<Book> books = mapper.readValue(inputStream, typeReference);
//		for (Book b : books) {
//			System.out.println("Name:" + b.getName() + 
//					           "Author:" + b.getAuthor() +
//					           "Category" + b.getCategory());
//		}
//		Book book = new Book();
//		book.setAuthor("Jack");
//		book.setName("Knyga");
//		book.setCategory("C");
//		book.setISBN("BN");
//		book.setPublication_date(180);
//		mapper.writeValue(new File("/home/karolis/demo/persons2.json"), book);
//		inputStream.close();
//	} catch (FileNotFoundException e) {
//			e.printStackTrace();
//	} catch (JsonParseException e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	} catch (JacksonException e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	} catch (IOException e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	}
		}
	}


