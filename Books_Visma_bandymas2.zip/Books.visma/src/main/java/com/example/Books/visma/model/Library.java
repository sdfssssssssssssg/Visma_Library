package com.example.Books.visma.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class Library {
private List<Book> library = new ArrayList<Book>();
private boolean takenOrNot;
private long longestPeriod = 60;
private Date taken_date;


	
	public Library(List<Book> library) {
	super();
	this.library = library;
}
	
	public void addToLibrary(Book book){
		library.add(book);
	}
	
	public void removeFromLibrary(Book book) {
		library.remove(book);
	}
	
	public Library() {
		// TODO Auto-generated constructor stub
	}

}
