package com.example.Books.visma.model;

import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
public class Book {
	
	@Id
	private final UUID GUID;

	
	private String name;
	private String author;
	private String category;
	private String language;
	private long Publication_date;
	
	@Column(unique = true)
	private String ISBN;
	
	
	
	public Book(@JsonProperty("GUID")  UUID gUID, @JsonProperty("Name") String name, @JsonProperty("Author") String author,
			@JsonProperty("Category") String category, @JsonProperty("Language") String language,
			@JsonProperty("Publication date") long publication_date,
			@JsonProperty("ISBN") String iSBN) {
		GUID = gUID;
		this.name = name;
		this.author = author;
		this.category = category;
		this.language = language;
		Publication_date = publication_date;
		ISBN = iSBN;
	}



	public Book() {
		this.GUID = null;
		// TODO Auto-generated constructor stub
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getAuthor() {
		return author;
	}



	public void setAuthor(String author) {
		this.author = author;
	}



	public String getCategory() {
		return category;
	}



	public void setCategory(String category) {
		this.category = category;
	}



	public String getLanguage() {
		return language;
	}



	public void setLanguage(String language) {
		this.language = language;
	}



	public long getPublication_date() {
		return Publication_date;
	}



	public void setPublication_date(long publication_date) {
		Publication_date = publication_date;
	}



	public String getISBN() {
		return ISBN;
	}



	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}

	
	public UUID getGUID() {
		return GUID;
	}


}