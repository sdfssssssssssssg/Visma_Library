package com.example.Books.visma.dao;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.json.simple.JSONObject;
import org.springframework.boot.SpringApplication;
import org.springframework.stereotype.Repository;

import com.example.Books.visma.BooksApplication;
import com.example.Books.visma.model.Book;

@Repository("FakeDao")
public class Library implements BookDao {

	public static List<Book> library = new ArrayList<>(); 
	
	public static List<Book> getLibrary() {
		return library;
	}

	public static void setLibrary(List<Book> library) {
		Library.library = library;
	}

	@Override
	public int insertBook(UUID GUID, Book book) {
		library.add(new Book(GUID, 
				book.getName(),
				book.getAuthor(), 
				book.getCategory(), 
				book.getLanguage(), 
				book.getPublication_date(), 
				book.getISBN()));
		return 1;
	}

	@Override
	public List<Book> findAllBooks() {
		return library;
	}

	@Override
	public Optional<Book> findBookById(UUID GUID) {
		return library.stream().filter(book -> book.getGUID().equals(GUID)).findFirst();
	}
	
	@Override
	public ArrayList<Book> findBooksByName(String name) {
//		return library.stream().filter(book -> book.getName().equals(name)).collect(Collectors.toList());
		ArrayList<Book> booksByName = new ArrayList<Book>();
		for (Book b : library) {
			if(b.getName().equals(name)) {
				booksByName.add(b);
			}
		}
		return booksByName;
	}
	
	@Override
	public List<Book> findBooksByAuthor(String author) {
		List<Book> booksByAuthor = new ArrayList<Book>();
		for (Book b : library) {
			if(b.getAuthor().equals(author)) {
				booksByAuthor.add(b);
			}
		}
		return booksByAuthor;
	}
	
	
	@Override
	public List<Book> findBooksByCategory(String category) {
		return library.stream().filter(book -> book.getCategory().equals(category)).collect(Collectors.toList());
	}
	
	@Override
	public List<Book> findBooksByLanguage(String language) {
		return library.stream().filter(book -> book.getLanguage().equals(language)).collect(Collectors.toList());
	}
	
	@Override
	public List<Book> findBooksByPublicationDate(long Publication_date) {
		return library.stream().filter(book -> book.getPublication_date() == Publication_date).collect(Collectors.toList());
	}
	
	@Override
	public int deleteBookbyId(UUID GUID) {
		Optional<Book> bookMaybe = findBookById(GUID);
		if (bookMaybe.isEmpty()) {
			return 0;
		}
		library.remove(bookMaybe.get());
		return 1;
	}

	@Override
	public int updateBookById(UUID GUID, Book update) {
		return findBookById(GUID)
				.map(book -> {
					int indexOfBookToUpdate = library.indexOf(book);
		            if (indexOfBookToUpdate >= 0) {
		            	library.set(indexOfBookToUpdate, new Book(GUID,
		            			update.getName(),
		            			update.getAuthor(), 
		            			update.getCategory(), 
		            			update.getLanguage(), 
		            			update.getPublication_date(), 
		            			update.getISBN()));
		            	return 1;
		            }
		            return 0;
		}).orElse(0);
	}
	
	
}
